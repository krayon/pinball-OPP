var searchData=
[
  ['var_5frot_5fleft',['Var_Rot_Left',['../classstd_funcs_1_1_std_funcs.html#aaafcf69308f2b1df782e48b7273b13c3',1,'stdFuncs::StdFuncs']]],
  ['var_5frot_5fright',['Var_Rot_Right',['../classstd_funcs_1_1_std_funcs.html#a37fe6c679b2b41f7f603a861760a934c',1,'stdFuncs::StdFuncs']]]
];
