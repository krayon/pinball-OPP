var searchData=
[
  ['kick',['Kick',['../classstd_funcs_1_1_std_funcs.html#a29024c76e3f50fb64e0d5edb3bcaa14e',1,'stdFuncs::StdFuncs']]]
];
