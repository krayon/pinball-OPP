var searchData=
[
  ['gamedata',['GameData',['../classgame_data_1_1_game_data.html',1,'gameData']]],
  ['globconst',['GlobConst',['../classglob_const_1_1_glob_const.html',1,'globConst']]]
];
