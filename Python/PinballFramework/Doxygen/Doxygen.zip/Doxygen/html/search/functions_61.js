var searchData=
[
  ['add_5fcard',['add_card',['../classhwobjs_1_1inp_brd_1_1_inp_brd.html#af015d509d2a05b5b6210d6404374f489',1,'hwobjs.inpBrd.InpBrd.add_card()'],['../classhwobjs_1_1led_brd_1_1_led_brd.html#ae7b2d30b456528981ddcaf0014ccde0c',1,'hwobjs.ledBrd.LedBrd.add_card()'],['../classhwobjs_1_1sol_brd_1_1_sol_brd.html#a2f5f9d655b2a55c78c7beb6254ea2b34',1,'hwobjs.solBrd.SolBrd.add_card()']]]
];
