var searchData=
[
  ['optmenucallback',['optmenucallback',['../classtk_inp_brd_1_1_tk_inp_brd.html#aec50dbaf50a04846b58029cda0260960',1,'tkInpBrd.TkInpBrd.optmenucallback()'],['../classtk_sol_brd_1_1_tk_sol_brd.html#a60e20532c957508e0c8bf42cc5eb2653',1,'tkSolBrd.TkSolBrd.optmenucallback()']]]
];
