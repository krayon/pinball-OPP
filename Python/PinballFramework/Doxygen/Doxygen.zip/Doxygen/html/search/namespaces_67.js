var searchData=
[
  ['gamedata',['gameData',['../namespacegame_data.html',1,'']]],
  ['globconst',['globConst',['../namespaceglob_const.html',1,'']]]
];
